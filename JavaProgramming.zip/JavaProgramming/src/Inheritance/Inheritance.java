package Inheritance;

/*
 * 1. A, B and C are classes
 * 2. A is a super class. B is a subclass of A. C is a subclass of B.
 * 3. Create three methods in each class, 2 methods are specific to each class and third
 * method (override method) should be in all three Classes A, B and C
 * 4. Create a class with main method. Create an object for each class A, B and C in main
 * method and call every method of each class using its own object/instance.
 * 5. Call an overridden method with super class reference to B and C class’s objects
 * 6. Runtime Polymorphism with Data Members/Instance variables, Repeat the above
 * process only for data member
 */

class A {
  int n = 10;

  void MethodA1() {
      System.out.println("This is Class A Method 1");
  }

  void MethodA2() {
      System.out.println("This is Class A Method 2");
  }

  void Method3() {
      System.out.println("This is override method - Class A");
  }
}

class B extends A {
  int n = 25;

  void MethodB1() {
      System.out.println("This is Class B Method 1");
  }

  void MethodB2() {
      System.out.println("This is Class B Method 2");
  }

  @Override 
  void Method3() {
      System.out.println("This is override method - Class B");
  }
}

class C extends B {
  int n = 33;

  void MethodC1() {
      System.out.println("This is Class C Method 1");
  }

  void MethodC2() {
      System.out.println("This is Class C Method 2");
  }

  @Override  
  void Method3() {
      System.out.println("This is override method - Class C");
  }
}

public class Inheritance {

	public static void main(String[] args) {
		
		 A a = new A();
	        a.MethodA1();
	        a.MethodA2();
	        a.Method3();
	       
	        B b = new B();
	        b.MethodB1();
	        b.MethodB2();
	        b.Method3();
	        
	        C c = new C();
	        c.MethodC1();
	        c.MethodC2();
	        c.Method3();

            A orm;
	        
	        orm = new B();
	        orm.Method3();
	       
	        orm = new C();
	        orm.Method3();

	       
	        A rtp;
	        rtp = new A();
	        System.out.println(rtp.n);
	        rtp = new B();
	        System.out.println(rtp.n);
	        rtp = new C();
	        System.out.println(rtp.n);
		

	}

}
