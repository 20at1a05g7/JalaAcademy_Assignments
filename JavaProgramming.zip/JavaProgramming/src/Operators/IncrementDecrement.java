package Operators;

// 2. Write a method for increment and decrement operators(++, --)

public class IncrementDecrement {
	
	static void preIncrement(int a, int b) 
	{
		int d;
		d = b + (++a); 
		System.out.println("Values after preincrement is :" + a +"," +d);
		
	}
	
	static void postIncrement(int a, int b) 
	{
		int d;
		d = b + (++a);
		System.out.println("Values after postincrement is: "+a +"," +d);
	}
	
	static void preDecrement(int a, int b) 
	{
		int d;
		d = b + (--a);
		System.out.println("Values after predecrement is: "+a +"," +d);
	}
	
	static void postDecrement(int a, int b) {
		int d;
		d = b + (a--);
		System.out.println("Values after postdecrement "+a +"," +d);
	}

	public static void main(String[] args) {
		
		int a = 10;
		int b = 5;
		preIncrement(a, b);
		postIncrement(a, b);
		preDecrement(a, b);
		postDecrement(a, b);
		

	}

}
