package Operators;

// 1. Write a function for arithmetic operators(+,-,*,/)

public class Arthemeticoperations {
	
	static void Add(int a, int b) {
		int add = a+b;
		System.out.println("Addition is:"+add);
	}
	
	static void Sub(int a, int b) {
		int sub=a-b;
		System.out.println("Subtraction is:"+sub);
	}
	
	static void Mul(int a, int b) 
	{
		int mul=a*b;
		System.out.println("Multiplication is:"+mul);
	}
	
	static void Div(int a, int b) {
		int div=a/b;
		System.out.println("Division is:"+div);
	}

	public static void main(String[] args) {
		int a=10;
		int b=2;
		Add(a, b);
		Sub(a, b);
		Mul(a, b);
		Div(a, b);

	}

}
