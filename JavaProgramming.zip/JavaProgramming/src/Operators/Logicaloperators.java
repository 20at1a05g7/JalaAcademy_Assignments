package Operators;

// 5. Programs on Logical AND,OR operator and Logical NOT

public class Logicaloperators {

	public static void main(String[] args) {
		
		int a = 20;
		int b = 10;
		int c = 5;
		
		//Logical AND(&&)
		System.out.println(a > b && a > c);
		System.out.println(a < b && a < c);
		System.out.println(a > b && a < c);
		
		//Logical OR(||)
		System.out.println(a > b || a > c);
		System.out.println(a < b || a < c);
		System.out.println(a < b || a > c);
		
		//Logical NOT [!()]
		System.out.println(!(a > b));
		System.out.println(!(a < b));
		

	}

}
