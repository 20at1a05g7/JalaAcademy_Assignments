package Operators;

// 6. Program for relational operators (<,<==, >, >==)


public class Relational {

	public static void main(String[] args) {
		 
		int a = 25;
		int b = 20;
		
		System.out.println(a < b);
		System.out.println(a > b);
		System.out.println(a <= b);
		System.out.println(a >= b);

	}

}
