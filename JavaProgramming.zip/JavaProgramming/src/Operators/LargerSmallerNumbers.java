package Operators;

// 7. Print the smaller and larger number

public class LargerSmallerNumbers {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 15;
		
		if(a>b)
		{
			System.out.println("Larger Number is " + a);
		}
		else
		{
			System.out.println("Smaller Number is "+ a);
		}
		
		if(b > a)
		{
			System.out.println("Larger Number is "+b);
		}
		else
		{
			System.out.println("Smaller Number is "+ b);
		}

	}

}
