package javabasics;

// 5. Define the local and Global variables with the same name and print both variables and understand the scope of the variables



public class LocalGlobalVariables {
	
	int a =07;
	
	void Localvariable()
	{
		int a = 25;
		System.out.println("Local variable is:"+a);
	}

	public static void main(String[] args) {
		
		LocalGlobalVariables obj = new LocalGlobalVariables();
		System.out.println("Instance variable a : " +obj.a);
		
		obj.Localvariable();

	}

}
