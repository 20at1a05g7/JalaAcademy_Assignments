package javabasics;

// 2. Write a program to print your name.


public class Printname {

	public static void main(String[] args) {
		
		String name = "Suresh";
		
		System.out.println("This is "+name);

	}

}
