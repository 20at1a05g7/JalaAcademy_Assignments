package javabasics;

// 1. How to create a class, object, method and its signature

public class Myclass {
	
	void Method()
	{
		System.out.println("This is Method");
	}

	public static void main(String[] args) {
		
		Myclass obj = new Myclass();
		
		obj.Method();

	}

}
