package javabasics;

// 6. Write a function to print your name and call the function from main method

public class FunctionCalling {
	
	static void Method()
	{
		System.out.println("This is 'Suresh'");
	}

	public static void main(String[] args) {
		
		Method();

	}

}
