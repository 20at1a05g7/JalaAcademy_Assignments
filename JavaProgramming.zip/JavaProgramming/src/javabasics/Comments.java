package javabasics;

// 3. Write a program for a Single line comment, multi-line and documentation comments

public class Comments {

	public static void main(String[] args) {
		
		System.out.println("//Single line comment");
		
		System.out.println("/*Multi-line comment */");
		
		System.out.println("/**Documentation comment*/");

	}

}
