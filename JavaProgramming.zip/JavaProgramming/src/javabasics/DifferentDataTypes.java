package javabasics;

// 4. Define variables for different Data Types int, Boolean, char, float, double and print on the console


public class DifferentDataTypes {

	public static void main(String[] args) {
		int a = 25;
		float b = 04.7f;
		double d = 77.777;
		char c = 'C';
		boolean B = false;
		
		System.out.println("Integer value"+a);
		System.out.println("Float value"+b);
		System.out.println("Double value"+d);
		System.out.println("Char value "+c);
		System.out.println("Boolean vlaue"+B);
		

	}

}
