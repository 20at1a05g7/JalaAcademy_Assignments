package AccessModifiers;

//1. Create a class with PRIVATE fields, private method and a main method. Print the fields
//in main method. Call the private method in main method.
//Create a sub class and try to access the private fields and methods from sub class.

public class PrivateFields {
	
	 private String name = "Suresh";
	 private int age = 24;
	 
	 private void pvtMethod() {
	    System.out.println("My Name is " + name + " and my age is " + age);
	 }

	public static void main(String[] args) {
		
		 PrivateFields obj = new PrivateFields();
	       
	        System.out.println(obj.age);
	        System.out.println(obj.name);
	        
	        obj.pvtMethod();

	}

}
