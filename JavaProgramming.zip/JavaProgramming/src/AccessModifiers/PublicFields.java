package AccessModifiers;

/*
 4. Create a class with PUBLIC fields and methods.
Access the public methods and fields from any class in the same package or different
package.
 */


class PublicClass {
    
    public String pName = "Public";

    public void publicMethod() {
        System.out.println("This is " + pName);
    }
}

public class PublicFields {

	public static void main(String[] args) {
		PublicClass pub = new PublicClass();
        
        pub.pName = "Public Method";
        
        pub.publicMethod();

	}

}
