package AccessModifiers;

/*
 3. Create a class with PROTECTED fields and methods. Access these fields and methods
from any other class in the same package.
Also, Access the PROTECTED fields and methods from child class located in a different
package
Access the PROTECTED fields and methods from any class in different package
 */

public class ProtectedFileds {
	
	protected String name;

    protected void ProtectedMethod() {
        System.out.println("This is a " + name);
    }
}

class protectedClass{

	public static void main(String[] args) {
		
		  ProtectedFileds pc = new ProtectedFileds();
	       
	      pc.name = "Protected Method";
	       
	      pc.ProtectedMethod();
	}

}
