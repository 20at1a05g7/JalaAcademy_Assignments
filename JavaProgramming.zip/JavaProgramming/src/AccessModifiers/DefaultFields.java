package AccessModifiers;

//2. Create a class with DEFAULT fields and methods. Access these fields and methods
//from any other class in the same package

class DefaultClass{
    
    int myAge;
    String myName;

    void defaultMethod() {
        System.out.println("My name is " + myName + " and my age is " + myAge);
    }
}

public class DefaultFields {

	public static void main(String[] args) {
		 DefaultClass obj = new DefaultClass();
	        
	     obj.myAge = 21;
	     obj.myName = "Sharan";
	        
	     obj.defaultMethod();

	}

}
