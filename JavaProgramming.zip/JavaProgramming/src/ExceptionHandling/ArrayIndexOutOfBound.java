package ExceptionHandling;

//9. Write a program to generate ArrayIndexOutOfBoundException

public class ArrayIndexOutOfBound {

	public static void main(String[] args) {
		
		  String[] arr = {"Suresh", "Shasi", "Sunitha", "Susheela"};
	      
	      try {
	          System.out.println(arr[5]);
	        }
	      catch (ArrayIndexOutOfBoundsException e){
	          System.err.println("ArrayIndexOutOfBoundsException caught");
	           
	          e.printStackTrace();
	        }

	}

}
