package Interfaces;
/*
* 08. Create a PUBLIC interface with fields and methods, fields should have values assigned.
* Implement this interface to some class and print the values of the interface fields and
* call the interface methods
*/

public interface InterfacePublicFields {
	
	int num = 25;
	
	public void myMethod();
}

class Method8 implements InterfacePublicFields{
	@Override
	public void myMethod() {
		System.out.println("This is Method");
	}

	public static void main(String[] args) {
		Method8 m = new Method8();
        System.out.println(num);
        m.myMethod();

	}

}