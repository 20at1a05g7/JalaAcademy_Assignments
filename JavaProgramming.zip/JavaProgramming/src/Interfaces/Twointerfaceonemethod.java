package Interfaces;
/*
* 04.Create two interfaces with one method each. Implement these two interfaces in one
* class.
*/

interface Method4 {
    void methodOne();
}

interface Method04 {
    void methodTwo();
}

public class Twointerfaceonemethod implements Method4, Method04 {
    @Override
    public void methodOne() {
        System.out.println("This is Method one");
    }

    @Override
    public void methodTwo() {
        System.out.println("This is Method two");
    }

	public static void main(String[] args) {
		Twointerfaceonemethod m = new Twointerfaceonemethod();
        //Calling the methods implemented
        m.methodOne();
        m.methodTwo();

	}

}
