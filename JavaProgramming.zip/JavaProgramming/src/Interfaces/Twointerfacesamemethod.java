package Interfaces;
/*
* 05. Create two interfaces with the same method (same signature) in both the interfaces.
* Implement these two interfaces in one class. Call the method.
*/

interface Method5{
	void sameMethod();
}

interface Method05{
	void sameMethod();
}

class Twointerfacesamemethod implements Method5, Method05{
	
	@Override
	public void sameMethod() {
		System.out.println("This is same method in both interfaces");
	}

	public static void main(String[] args) {
		
		Twointerfacesamemethod m = new Twointerfacesamemethod();
        m.sameMethod();

	}

}
