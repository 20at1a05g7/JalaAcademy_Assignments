package Interfaces;

//2. Create an interface with two methods, but implement only one in a class. Call the method implemented.

interface Method2{
	void Method1();
	
	void Method2();
}

public class Interfacetwomethods implements Method2{
	
	@Override
	public void Method1() {
		System.out.println("First Method");
	}
	
	@Override
	public void Method2() {
		System.out.println("Second Method");
	}

	public static void main(String[] args) {
		
		Interfacetwomethods m= new Interfacetwomethods();
		
		m.Method1();
		m.Method2();

	}

}
