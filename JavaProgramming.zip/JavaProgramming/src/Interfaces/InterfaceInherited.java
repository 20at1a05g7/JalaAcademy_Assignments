package Interfaces;

//07. Create an interface and inherit it from the other interface.

interface Method7 {
    void methodOne();
}

interface Method07 extends Method7 {
    void methodTwo();
}

class InterfaceInherited implements Method07{
	
	@Override
    public void methodOne() {
        System.out.println("This is first method");
    }
    @Override
    public void methodTwo() {
        System.out.println("This is second method");
    }

	public static void main(String[] args) {
		
		InterfaceInherited m = new InterfaceInherited();
        
        m.methodOne();
        m.methodTwo();

	}

}
