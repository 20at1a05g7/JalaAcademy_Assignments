package Interfaces;

//1. Create an interface with only one method and implement it in a class. Call the method implemented.

interface Method1{
	void oneMethod();
}
public class Interfaceonemethod implements Method1{
	
	public void oneMethod() {
		System.out.println("This is Method");
	}

	public static void main(String[] args) {
		Interfaceonemethod m1 = new Interfaceonemethod();
		
		m1.oneMethod();

	}

}
