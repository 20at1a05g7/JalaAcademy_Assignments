package ThisandSuper;
/*
* 1. Print the fields/instance members of the current class using this and without using object
* 3. Call constructor of the current class using this()
* 4. Call argument constructor of current class using this()
*/

public class CallUsingThis {
	
	  int num;
	  String name;

	  CallUsingThis() {
	      this(11, "Suresh");
	    }

	    CallUsingThis(int num, String name) {
	        this.num = num;
	        this.name = name;
	        System.out.println(num + " " + name);
	    }

	public static void main(String[] args) {
		 CallUsingThis ts1 = new CallUsingThis();
	     CallUsingThis ts = new CallUsingThis(12, "Shasi");

	}

}
