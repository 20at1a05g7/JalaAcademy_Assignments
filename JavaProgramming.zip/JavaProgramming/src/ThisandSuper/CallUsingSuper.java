package ThisandSuper;
/*
* 2. Print the fields/instance members of the parent class using super
* 5. Call constructor of the parent class using super()
*/

class Parent {
    String name = "Suresh";

    Parent() {
        System.out.println("This is parent class constructor");
    }
}

class Child extends Parent {
    String name = "Shasi";

    Child() {
        super();
        System.out.println("This is child class constructor");
    }

    void myMethod() {
        System.out.println("My name is " + super.name);
    }
}

public class CallUsingSuper {

	public static void main(String[] args) {
		 Child c = new Child();
	        c.myMethod();

	}

}
