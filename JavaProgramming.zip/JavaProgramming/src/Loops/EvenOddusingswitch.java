package Loops;

import java.util.Scanner;

//1. Program to check whether a number is EVEN or ODD using switch

public class EvenOddusingswitch {

	public static void main(String[] args) {
		
		System.out.print("Enter a number: ");
		int num=new Scanner(System.in).nextInt();
		
		switch(num%2) {
		
		case 0 : System.out.println(num+" is Even number");
		         break;
		         
		case 1 : System.out.println(num+" is Odd number");
		         break;
		}

	}

}
