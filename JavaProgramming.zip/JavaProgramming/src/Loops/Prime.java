package Loops;

//9. Write a program to find the prime or not

import java.util.Scanner;

public class Prime {
	
	static boolean isPrime(int n) {
		for(int i=2;i<n/2;i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		System.out.print("Enter a number : ");
		int num = new Scanner(System.in).nextInt();
		
		System.out.println(isPrime(num));

	}

}
