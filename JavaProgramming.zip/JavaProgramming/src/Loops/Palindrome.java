package Loops;

//10. Write a program to palindrome or not.

import java.util.Scanner;

public class Palindrome {
	
	static  boolean ispalindrome(int num) {
		
		int rem, sum=0, temp;
		temp=num;
		
		while(num>0) {
			rem=num%10;
			sum=sum*10+rem;
			num=num/10;
		}
			
		return temp == sum;			
	}

	public static void main(String[] args) {
		System.out.println("Enter a number: ");
		int num=new Scanner(System.in).nextInt();
		
		if(ispalindrome(num)) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not Palindrome");
		}

	}

}
