package Loops;

// 6. Write a program to print even number between 10 and 100 using while

public class EvennumbersUsingWhile {

	public static void main(String[] args) {
		
		System.out.println("Even Number from 10 to 100: " );
		
		int i=10;
		
		while(i<=100)
		{
			System.out.println(i);
			i +=2;
		}

	}

}
