package Loops;

// 3. Program to equal operator and not equal operators.
// 4. Write a program to print the odd and even numbers.

import java.util.Scanner;

public class EvenOdd {
	
	static void Evennumbers(int n){
		
		System.out.println("Even numbers from 0 to "+ n);
		
		for(int i=1;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.print(i + " ");
			}
		}
		System.out.println(" ");
	}
	
	static void oddNumbers(int n) {
		System.out.println("\nOdd Numbers from 1 to "+ n);
		
		for(int i=1;i<=n;i++)
		{
			if(i%2!=0)
			{
				System.out.print(i + " ");
			}
		}
	}

	public static void main(String[] args) {
		
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a Number: ");
		
		n=sc.nextInt();
		Evennumbers(n);
		oddNumbers(n);
		

	}

}
