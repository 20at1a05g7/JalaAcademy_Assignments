package Loops;

// 8. Write a program to find Armstrong number or not

import java.util.Scanner;

public class Armstrong {
	
	static boolean isArmstrong(int n) {
		int rem, sum=0;
		
		int temp = n;
		
		while(n>0) {
			rem=n%10;
			sum=sum+(rem*rem*rem);
			n=n/10;
			}
		return temp == sum;
		
	}

	public static void main(String[] args) {
		
		System.out.print("Enter a number: ");
		int num = new Scanner(System.in).nextInt();
		
		if(isArmstrong(num)) {
			System.out.println(num + " is Armstrong number");
		}
		else {
			System.out.println(num + " is not Armstrong number");
		}
		

	}

}
