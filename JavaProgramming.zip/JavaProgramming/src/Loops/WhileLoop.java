package Loops;

// 2. Write a java program to print 1 to 20 numbers using the while loop.


public class WhileLoop {

	public static void main(String[] args) {
		
		int n = 1;
		
		while(n <= 20) {
			System.out.print(n + " ");
			n++;
		}

	}

}
