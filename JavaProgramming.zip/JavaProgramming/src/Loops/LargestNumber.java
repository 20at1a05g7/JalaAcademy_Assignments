package Loops;

//  5. Write a program to print largest number among three numbers.

import java.util.Scanner;

public class LargestNumber {

	public static void main(String[] args) {
		
		int a, b, c;
		Scanner num = new Scanner(System.in);
		
		System.out.print("Enter First number: ");
		a=num.nextInt();
		System.out.print("Enter Second number: ");
		b=num.nextInt();
		System.out.print("Enter Third number: ");
		c=num.nextInt();
		
		if((a>b) && (a>c)) {
			System.out.println("Largest Number is: "+a);
		}
		
		else if((b>a) && (b>c)) {
			System.out.println("Largest Number is: "+b);
			
		}
		else {
			System.out.println("Largest Number is: "+c);
		}

	}

}
