package Collections;
/*
* 3.Create a HashSet with at least 10 elements of type String
* - Write program covering all the operations of HashSet
*/
import java.util.Iterator;

public class HashSet {

	public static void main(String[] args) {
	

        java.util.HashSet<String> hash = new java.util.HashSet<>();

        //a. adding elements to the HashSet using add() method
        hash.add("zero");
        hash.add("one");
        hash.add("two");
        hash.add("three");
        hash.add("four");
        hash.add("five");
        hash.add("six");
        hash.add("seven");
        hash.add("eight");
        hash.add("nine");
        hash.add("ten");
        
        hash.add("nine");
        System.out.println("\nAfter adding elements to HashSet :");
        
        System.out.println("hash = " +hash);


        //b. Iterating through the HashSet by using Iterator object
        Iterator<String> itr = hash.iterator();
        System.out.println("\nIterating through the HashSet : ");
        while (itr.hasNext()) {
            System.out.print(itr.next() + " ");
        }
        System.out.println(" ");

        //c. Create a clone/copy of HashSet using clone() method
        System.out.println("\nclone/copy of HashSet : ");
        System.out.println(hash.clone());

        //c. Removing a specific element using remove() method
        hash.remove("zero");
        System.out.println("\nAfter removing element 'zero' :");
        System.out.println("hash = " + hash);

        //f. Checking if the set is empty using isEmpty() method
        System.out.println("\nChecking if the set is empty :");
        System.out.println(hash.isEmpty());


        //h. Finding the size of the HashSet using size() method
        System.out.println("\nSize of the HashSet : ");
        System.out.println(hash.size());

        //d. Checking if element is present in the HashSet using contains() method
        System.out.println("\nElement 'one' is present in the HashSet : ");
        System.out.println(hash.contains("one")); 

        //j. Removing all elements of the HashSet using clear() method
        System.out.println("\nAfter removing all elements of the HashSet :");
        hash.clear();
        System.out.println("hash = " + hash);

	}

}
