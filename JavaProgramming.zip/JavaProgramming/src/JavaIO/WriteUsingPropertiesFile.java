package JavaIO;

//10.Write a program to write data to properties file

import java.io.FileOutputStream;
import java.util.Properties;

public class WriteUsingPropertiesFile {

	public static void main(String[] args) {
		
		   try {
	          
	            Properties props = new Properties();
	          
	            props.put("Name", "Suresh");
	            props.put("E.no", "25");
	            props.put("College", "GPCET");

	            
	            FileOutputStream outputStrem = new FileOutputStream("C:\\\\Users\\\\HP\\\\eclipse-workspace\\\\JavaProgramming\\\\src\\\\JavaIO\\\\pf.txt");
	           
	            props.store(outputStrem, "This is a sample properties file");
	            System.out.println("Properties file created");

	        } catch (Exception e) {
	            
	            e.printStackTrace();
	        }

	}

}
