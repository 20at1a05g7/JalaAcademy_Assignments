package Constructors;



class ChildClass extends ParentClass {

    String clg;
    String city;

    ChildClass() {
        super();
    }
    
    ChildClass(int rollNo) {
        super(rollNo);
    }
 
    ChildClass(String name, String branch, String clg, String city) {
        super(name, branch);
        this.clg = clg;
        this.city = city;
        System.out.println("College : " + this.clg);
    }
}

public class CallSuperfromChild {

	public static void main(String[] args) {
		
		 new ChildClass();
	     new ChildClass(25);
	     new ChildClass("Suresh", "CSE", "GPCET","Hyderabad");

	}

}
