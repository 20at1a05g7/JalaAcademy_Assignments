package Constructors;
/*
* 01. Write a class with a default constructor, one argument constructor and two argument
* constructors. Instantiate the class to call all the constructors of that class from
* a main class
*/

class ParentClass {
    int rollNo;
    String name;
    String branch;

    ParentClass() {
        System.out.println("Student Details");
    }

    ParentClass(int rollNo) {
        this.rollNo = rollNo;
        System.out.println("Roll No : " + this.rollNo);
    }

    ParentClass(String name, String branch) {
        this.name = name;
        this.branch = branch;
        System.out.println("Name : " + this.name);
        System.out.println("Branch : " + this.branch);
    }
}

public class DefaultOneTwoArgument {

	public static void main(String[] args) {
		
		 new ParentClass();
	     new ParentClass(25);
	     new ParentClass("Suresh", "CSE");

	}

}
