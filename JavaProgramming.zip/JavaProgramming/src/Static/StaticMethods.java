package Static;

/*
 * 1. Write a class with 2 static variables, 2 Instance variables, 2 static methods, 2 instance
 * methods and a main method.
 * 2. Print instance variables in static methods
 * 3. Print static variables in Instance methods
 * 4. Call instance methods in static methods
 * 5. Call static methods in instance methods
 * 6. Print all the static, instance variables in main method
 * 7. Call static methods and instance methods in main method
 */

public class StaticMethods {
	
	    static int sv1 = 11;
	    static int sv2 = 22;

	    
	    int iv1 = 33;
	    int iv2 = 44;

	    
	    static void staticMethod1() {
	       
	        StaticMethods obj = new StaticMethods();
	        
	        System.out.println("Instance variables: " + obj.iv1 + ", " + obj.iv2);
	    }

	    
	    void instanceMethod1() {
	       
	        System.out.println("Static variables: " + sv1 + ", " + sv2);
	    }

	    
	    static void staticMethod2() {
	
	        StaticMethods obj = new StaticMethods();
	        obj.instanceMethod1();
	    }

	    
	    void instanceMethod2() {
	        
	        staticMethod1();
	    }

	public static void main(String[] args) {
		
		    StaticMethods stc = new StaticMethods();

	        System.out.println("Static variables: " + sv1 + ", " + sv2);
	        System.out.println("Instance variables: " + stc.iv1 + ", " + stc.iv2);

	        staticMethod1();
	        staticMethod2();
	       
	        stc.instanceMethod1();
	        stc.instanceMethod2();

	}

}
