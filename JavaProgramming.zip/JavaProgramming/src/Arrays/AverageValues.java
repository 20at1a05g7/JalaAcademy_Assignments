package Arrays;

// 2. Write a function to calculate the average value of an array of integers

public class AverageValues {
	
	static int Avgvalues(int[] arr) {
		
		int sum=0,Avg;
		for(int i=0;i<arr.length;i++) {
			sum=sum+arr[i];
			
		}
		Avg=sum/arr.length;
		return Avg;
	}

	public static void main(String[] args) {
		
        int[] arr= {10, 20, 30, 40};
        System.out.println("Average values of Array: "+Avgvalues(arr));
      }

}
