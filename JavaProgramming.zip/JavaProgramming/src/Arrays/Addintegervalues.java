package Arrays;

//1. Write a function to add integer values of an array

public class Addintegervalues {
	
	static int Sumarr(int[] arr) {
		int sum =0;
		for(int i=0;i<arr.length;i++) {
			sum=sum+arr[i];
		}
		return sum;
	}

	public static void main(String[] args) {
		
		int[] arr = {5, 10, 15, 20, 25};
		
		System.out.println("Sum of array values: "+Sumarr(arr));

	}

}
